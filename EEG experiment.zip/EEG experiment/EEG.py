from psychopy import visual, core, event, data, gui
import glob #For file names
import pandas as pd #For creating data frame and saving log file
import os #To create new directory
from numpy import average
from numpy.random import shuffle
import random 
from triggers import setParallelData


# Dialogue box
box = gui.Dlg(title = "EEG experiment")
box.addField("Identification: ") 
box.addField("Age: ")
box.addField("Gender: ", choices=["Female", "Male", "Other" ])
box.show()

if box.OK: #To retrieve data from popup window
    ID = box.data[0]
    AGE = box.data[1]
    GENDER = box.data[2]
elif box.Cancel:
    core.quit()
    
#Inserting the images for an experiment
#stimuli = glob.glob("Stimuli/stim*.jpg")

stimuli1 = os.listdir("Stimuli")
stimuli1 = [f for f in stimuli1 if f.endswith(".jpg" or ".png")]

random.shuffle(stimuli1) #Shuffles stimuli randomly

stimuli = stimuli1.copy()

random.shuffle(stimuli1) #Shuffles stimuli randomly
stimuli.extend(stimuli1)

win = visual.Window(fullscr = True, color = "black") #Adjusts the window

#Defining columns for the data set which would help to keep track of the types of stimuli that are presented   
columns = ['ID', 'age', 'gender', 'stimuli', 'abstraction']
logfile = pd.DataFrame(columns=columns)
logfile_name = os.path.join("data", "{}.csv".format(ID))

instructions = ''' 
Welcome to the experiment! \n\n
Soon you will presented with a sequence of images. \n\n
All you have to do is to sit still and observe them. Images will be presented in the middle of the screen,
with a blank canvas in between. \n\n
When you are ready, press <SPACE>, and first image will appear in 2 s.
'''

goodbye = ''' 
That's it! Thank you for your participation!
'''

#Defining functions

#To show the message:
def msg(txt):
    message = visual.TextStim(win, text = txt, alignText = "center", height = 0.05)
    message.draw()
    win.flip()
    event.waitKeys()

#Evaluating the level of abstraction:
def get_level(img):
    if img[5] == "1":
        level = 1
    if img[5] == "2":
        level = 2
    if img[5] == "3":
        level = 3
    if img[5] == "4":
        level = 4
    return level



def get_image(stimulus, abstraction, int1 = 2, int2 = 1):
    pic = visual.ImageStim(win, image = os.path.join("Stimuli", stimulus))
    #black canvas:
    blank = visual.Rect(win, width = 700, height = 525, fillColor = "black")
    pic.draw() #takes picture
    win.callOnFlip(setParallelData, abstraction)
    win.flip()
    win.callOnFlip(setParallelData, 0)
    core.wait(int1) 
    blank.draw() #shows blank screen
    win.flip()
    core.wait(int2) #keeps blank screen for 250 ms
    


#Experiment

msg(instructions)
core.wait(2) #Maybe needed so participant could press the button, and then continue to stay still until the first stimulus is shown

for image in stimuli:
    print(image)
    stimuli = image[7]
    abstraction = get_level(image)    
    get_image(image, abstraction)
    logfile = logfile.append({
            'ID': ID,
            'age': AGE,
            'gender': GENDER,
            'stimuli': stimuli,
            'abstraction': abstraction}, ignore_index = True)
    

logfile.to_csv(logfile_name)

msg(goodbye)
core.wait(2)
core.quit()
